"""
下面的文件将会从csv文件中读取读取短信与电话记录，
你将在以后的课程中了解更多有关读取文件的知识。
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)


"""
任务1：
短信和通话记录中一共有多少电话号码？每个号码只统计一次。
输出信息：
"There are <count> different telephone numbers in the records." """

number_1 = [x for [x,y,z] in texts]
number_2 = [y for [x,y,z] in texts]
number_3 = [a for [a,b,c,d] in calls]
number_4 = [b for [a,b,c,d] in calls]
number = number_1 + number_2 + number_3 + number_4
number_new = set(number)
print('There are ' + str(len(number_new)) + ' different telephone numbers in the records')



